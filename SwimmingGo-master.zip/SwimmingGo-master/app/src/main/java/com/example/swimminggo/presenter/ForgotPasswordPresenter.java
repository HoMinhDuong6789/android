package com.example.swimminggo.presenter;

public interface ForgotPasswordPresenter {

    public void onValidateMail(String email);
    public void onSendMail(String email);
}
