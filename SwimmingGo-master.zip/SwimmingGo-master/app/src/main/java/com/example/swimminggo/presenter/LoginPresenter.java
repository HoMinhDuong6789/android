package com.example.swimminggo.presenter;

public interface LoginPresenter {
    void onLogin(String username, String password);
}
