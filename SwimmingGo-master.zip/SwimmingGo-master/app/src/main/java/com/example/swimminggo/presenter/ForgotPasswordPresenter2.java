package com.example.swimminggo.presenter;

public interface ForgotPasswordPresenter2 {
    void onSendOtp(String otp);
}
