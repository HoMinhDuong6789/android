package com.example.swimminggo.view.coach;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.swimminggo.R;

public class ListExercise extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_exercise);
    }
}
