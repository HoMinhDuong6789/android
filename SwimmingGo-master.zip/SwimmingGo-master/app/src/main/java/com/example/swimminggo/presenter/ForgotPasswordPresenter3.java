package com.example.swimminggo.presenter;

public interface ForgotPasswordPresenter3 {
    public void onValidatePassword(String password, String rePassword);
    public void onSubmit(String password, String otp);
}
