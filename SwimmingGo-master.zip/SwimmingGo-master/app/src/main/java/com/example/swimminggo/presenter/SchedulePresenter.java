package com.example.swimminggo.presenter;

import com.example.swimminggo.models.Date;

public interface SchedulePresenter {
    void loadListLessonPlanByDate(Date date);
}
